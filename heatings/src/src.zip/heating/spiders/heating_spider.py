import scrapy

from heating.items import heatingItem

class heatingSpider(scrapy.Spider):
    name = "heating"
    allowed_domains = ["idealo.de"]
    start_urls = [
        "http://www.idealo.de/preisvergleich/ProductCategory/18406F1529515-1898979.html?param.alternativeView=true&param.resultlist.count=50"
    ]

    #===========================================================================
    # def parse(self, response):
    #     for sel in response.xpath('//td'):
    #         title = sel.xpath('a/text()').extract()
    #         link = sel.xpath('a/@href').extract()
    #         desc = sel.xpath('text()').extract()
    #         print title, link, desc
    #===========================================================================

    #===========================================================================
    # def parse(self, response):
    #     for sel in response.xpath('//tr'):
    #         item = heatingItem()
    #         item['title'] = sel.xpath('td/a[@class="offer-title link-2 webtrekk"]/text()').extract()
    #         item['link'] = sel.xpath('td[@class="va-middle"]/a/@href').extract()
    #         item['pricerange'] = sel.xpath('td[@class="va-middle"]/a/span[@class="price bold nobr block fs-18"]/text()').extract()
    #         
    #         yield item
    #===========================================================================

    #===========================================================================
    # helpful links on working with xpath
    #     http://doc.scrapy.org/en/latest/topics/selectors.html#working-with-relative-xpaths
    #     http://plasmasturm.org/log/xpath101/
    #     http://stackoverflow.com/questions/18433376/xpath-select-certain-child-nodes
    #     
    #     
    #===========================================================================
        
    
    def parse(self, response):
#        for href in response.css("ul.directory.dir-col > li > a::attr('href')"):
            for href in response.css("td.info >  a::attr('href')"):
                url = response.urljoin(href.extract())
                yield scrapy.Request(url, callback=self.parse_dir_contents)
   
    
    def parse_dir_contents(self, response):
        for sel in response.xpath('//tr'):
            item = heatingItem()
            item['title'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/text()').extract()
            
            # title seems to be in a child node sometimes, read this: http://stackoverflow.com/questions/18433376/xpath-select-certain-child-nodes
            # item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/script[@type="text/javascript"]/following-sibling::*').extract()
            # item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/script[@type="text/javascript"]/node()').extract()
            item['longtitle'] = sel.xpath('td[@class="title"]/text()[0]').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/node()').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/text()').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/node()').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/text()').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/a[2]').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/*').extract()
            ## item['longtitle'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/script[@type="text/javascript"]/text()').extract()
            
            
            item['linkwithprice'] = sel.xpath('td[@class="title"]/a[@class="offer-title link-2 webtrekk wt-prompt"]/@href').extract()
            yield item
